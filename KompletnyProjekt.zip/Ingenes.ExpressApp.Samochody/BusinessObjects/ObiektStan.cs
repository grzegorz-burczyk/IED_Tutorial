﻿using System;
using System.Linq;
using System.Text;
using DevExpress.Xpo;
using DevExpress.ExpressApp;
using System.ComponentModel;
using DevExpress.ExpressApp.DC;
using DevExpress.Data.Filtering;
using DevExpress.Persistent.Base;
using System.Collections.Generic;
using DevExpress.ExpressApp.Model;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;
using DevExpress.ExpressApp.ConditionalAppearance;
using Ingenes.ExpressApp.Modules.CoreModule.BusinessObjects;
using Ingenes.ExpressApp.Modules.BaseModule.BusinessObjects.Operator;
using Ingenes.ExpressApp.Modules.BaseModule.Controllers;
using Ingenes.ExpressApp.Modules.BaseModule.Interfaces;
using Ingenes.ExpressApp.Modules.BaseModule.BusinessObjects.Slowniki;
using static Ingenes.ExpressApp.Modules.BaseModule.Interfaces.IDocSygnature;
using Ingenes.ExpressApp.Modules.CoreModule.Interfaces;
using System.Drawing;

namespace Ingenes.ExpressApp.Samochody.BusinessObjects
{
    [Persistent("ObiektStany")]
    [NavigationItem("Kanban")]
    [VisibleInReports, VisibleInDashboards]
    [DefaultProperty("StanSamochodu")]
    public class ObiektStan : BaseObject
    { // Inherit from a different class to provide a custom primary key, concurrency and deletion behavior, etc. (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument113146.aspx).
        public ObiektStan(Session session)
            : base(session)
        {
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place your initialization code here (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112834.aspx).
        }

        private string _StanSamochodu;
        [XafDisplayName("StanSamochodu"), ToolTip("StanSamochodu")]
        [Persistent("StanSamochodu"), RuleRequiredField(DefaultContexts.Save)]
        public string StanSamochodu
        {
            get { return _StanSamochodu; }
            set { SetPropertyValue("Nazwa", ref _StanSamochodu, value); }
        }

        [Association("samochod-obiektstan"), DevExpress.Xpo.Aggregated]
        public XPCollection<samochod> Samochody
        {
            get { return GetCollection<samochod>("Samochody"); }
        }
    }
}