﻿using DevExpress.ExpressApp;
using DevExpress.ExpressApp.ConditionalAppearance;
using DevExpress.ExpressApp.DC;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;
using DevExpress.Xpo;
using Ingenes.ExpressApp.Modules.BaseModule.BusinessObjects.Operator;
using Ingenes.ExpressApp.Modules.CoreModule.Interfaces;
using System;
using System.ComponentModel;
using System.Drawing;

namespace Ingenes.ExpressApp.Samochody.BusinessObjects
{
    [DefaultClassOptions]
    [NavigationItem("Ewidencja Samochodow")]
    [ImageName("BO_Car")]
    [DefaultProperty("NrRejestracyjny")]
    //[DefaultListViewOptions(MasterDetailMode.ListViewOnly, false, NewItemRowPosition.None)]
    [Persistent("Samochody")]
    [Appearance("ZblizaSiePrzeglad", AppearanceItemType = "ViewItem", TargetItems = "DataPrzegladu", Criteria = "IsOutlookIntervalLaterThisMonth([DataPrzegladu])", Context = "ListView", BackColor = "Yellow")]
    [Appearance("PrzegladNiewazny", AppearanceItemType = "ViewItem", TargetItems = "DataPrzegladu", Criteria = "IsOutlookIntervalYesterday([DataPrzegladu])", Context = "ListView", BackColor = "Red")]
    [Appearance("WylaczAktywacje", AppearanceItemType = "Action", TargetItems = "samochod.Aktywacja", Criteria = "[Aktywny] = True", Context = "Any", Enabled = false)]
    [Appearance("WylaczDeaktywacje", AppearanceItemType = "Action", TargetItems = "samochod.Deaktywacja", Criteria = "[Aktywny] = False", Context = "Any", Enabled = false)]
    // Specify more UI options using a declarative approach (https://documentation.devexpress.com/#eXpressAppFramework/CustomDocument112701).

    public class samochod : BaseObject, Ingenes.ExpressApp.Modules.CoreModule.Interfaces.IKanban
    { // Inherit from a different class to provide a custom primary key, concurrency and deletion behavior, etc. (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument113146.aspx).
        public samochod(Session session)
            : base(session)
        {
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place your initialization code here (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112834.aspx).
            DataUtworzenia = DateTime.Today;
        }

        private string _NrRejestracyjny;
        [XafDisplayName("Numer Rejestracyjny"), ToolTip("Nr Rejestracyjny")]
        [RuleRequiredField(DefaultContexts.Save)]
        public string NrRejestracyjny
        {
            get { return _NrRejestracyjny; }
            set { SetPropertyValue("NrRejestracyjny", ref _NrRejestracyjny, value); }
        }

        private string _Marka;
        [XafDisplayName("Marka"), ToolTip("Marka")]
        public string Marka
        {
            get { return _Marka; }
            set { SetPropertyValue("Marka", ref _Marka, value); }
        }

        private int _RokProdukcji;
        [XafDisplayName("Rok Produkcji"), ToolTip("Rok Produkcji")]
        public int RokProdukcji
        {
            get { return _RokProdukcji; }
            set { SetPropertyValue("RokProdukcji", ref _RokProdukcji, value); }
        }

       
        private DateTime _DataUtworzenia;
        [XafDisplayName("Data Utworzenia"), ToolTip("Data Utworzenia")]
        [ReadOnly(true)]
        [VisibleInListView(true)]
        public DateTime DataUtworzenia
        {
            get { return _DataUtworzenia; }
            set { SetPropertyValue("DataUtworzenia", ref _DataUtworzenia, value); }
        }

        private DateTime _DataPrzegladu;
        [XafDisplayName("Data Przeglądu"), ToolTip("Data Przeglądu")]
        [RuleRequiredField(DefaultContexts.Save)]
        public DateTime DataPrzegladu
        {
            get { return _DataPrzegladu; }
            set { SetPropertyValue("DataPrzegladu", ref _DataPrzegladu, value); }
        }

        private bool _Aktywny;
        public bool Aktywny
        {
            get { return _Aktywny; }
            set { SetPropertyValue("Aktywny", ref _Aktywny, value); }
        }

        private Operator wystawil;
        [XafDisplayName("Wystawił")]
        [VisibleInListView(false), VisibleInLookupListView(false)]

        public Operator Wystawil
        {
            get { return wystawil; }
            set { SetPropertyValue("Wystawil", ref wystawil, value); }
        }

        private int _OstatniPrzebieg;
        [ReadOnly(true)]
        public int OstatniPrzebieg
        {
            get { return _OstatniPrzebieg; }
            set { SetPropertyValue("OstatniPrzebieg", ref _OstatniPrzebieg, value); }
        }

        [Association("samochod-przejazdy"), DevExpress.Xpo.Aggregated]
            public XPCollection<SamochodPrzejazd> Przejazdy
            {
                get { return GetCollection<SamochodPrzejazd>("Przejazdy"); }
            }

        [Association("samochod-samochodaktywacja"), DevExpress.Xpo.Aggregated]
            public XPCollection<SamochodAktywacjaZmiany> SamochodAktywacjaZmiany
            {
                get { return GetCollection<SamochodAktywacjaZmiany>("SamochodAktywacjaZmiany"); }
            }


        #region IKanban
        private string _opis;
        [XafDisplayName("Opis"), ToolTip("Opis")]
        [Persistent("Opis")]
        public string Opis
        {
            get { return _opis; }
            set { SetPropertyValue("Opis", ref _opis, value); }
        }

        private ObiektStan _stan;
        [XafDisplayName("Stan"), ToolTip("Stan")] [Association("samochod-obiektstan")]
        [Persistent("Stan"), RuleRequiredField(DefaultContexts.Save)]
        public ObiektStan Stan
        {
            get { return _stan; }
            set { SetPropertyValue("Stan", ref _stan, value); }
        }


        private string _imieNazwisko;
        [XafDisplayName("Imię i nazwisko"), ToolTip("Imię i nazwisko")]
        [Persistent("ImieNazwisko"), RuleRequiredField(DefaultContexts.Save)]
        public string ImieNazwisko
        {
            get { return _imieNazwisko; }
            set { SetPropertyValue("ImieNazwisko", ref _imieNazwisko, value); }
        }


        [Browsable(false)]
        public Guid Id
        {
            get
            {
                return Oid;
            }
        }

        [Browsable(false)]
        public string Caption
        {
            get
            {
                return NrRejestracyjny;
            }
        }

        [Browsable(false)]
        public string Description
        {
            get
            {
                return Opis;
            }
        }

        public Color Label
        {
            get
            {
                if (Aktywny)
                {
                    return Color.Green;
                }
                else
                {
                    return Color.Red;
                }
            }
        }

        [Browsable(false)]
        public ObiektStan Status
        {
            get
            {
                return this.Stan;
            }
        }

        EnableChangeStatusRetValue IKanban.IsEnabledChangeStatus(IObjectSpace os, object prevStatusm, object newStatus)
        {
            return null;
        }
        public bool ChangeStatus(IObjectSpace os, object prevStatus, object newStatus)
        {
            try
            {
                this.Stan = (ObiektStan)newStatus;
            }
            catch
            {
            }
            return true;
        }
        private byte[] _obrazek;
        [XafDisplayName("Obrazek")]
        [Persistent("Obrazek")]
        [EditorAlias(DevExpress.ExpressApp.Editors.EditorAliases.ImagePropertyEditor)]
        public byte[] Obrazek
        {
            get { return _obrazek; }
            set { SetPropertyValue("Obrazek", ref _obrazek, value); }
        }
        [Browsable(false)]
        public byte[] OperatorImage
        {
            get
            {
                return Obrazek;

            }
        }

        [Browsable(false)]
        public string OperatorName
        {
            get
            {
                return ImieNazwisko;
            }
        }
        private int _index;
        [Persistent("Index")]
        [Browsable(false)]
        public int Index
        {
            get { return _index; }
            set { SetPropertyValue("Index", ref _index, value); }
        }
        object IKanban.Status
        {
            get
            {
                return this.Status;
            }
        }
        #endregion

        [Action(Caption = "Aktywacja", ConfirmationMessage = "Are you sure?", ImageName = "Attention", AutoCommit = false)]
            public void Aktywacja()
        { 

            // Trigger a custom business logic for the current record in the UI (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112619.aspx)
            this.Aktywny = true;
            SamochodAktywacjaZmiany samochodAktywacjaZmiany = new SamochodAktywacjaZmiany(Session);
            samochodAktywacjaZmiany.Samochod = this;
            samochodAktywacjaZmiany.Data = DateTime.Today;
            samochodAktywacjaZmiany.Operacja = "Aktywacja";
            samochodAktywacjaZmiany.Save();
        }



        [Action(Caption = "Deaktywacja", ConfirmationMessage = "Are you sure?", ImageName = "Attention", AutoCommit = true)]
        public void Deaktywacja()
        {
            // Trigger a custom business logic for the current record in the UI (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112619.aspx).
            this.Aktywny = false;
            SamochodAktywacjaZmiany samochodAktywacjaZmiany = new SamochodAktywacjaZmiany(Session);
            samochodAktywacjaZmiany.Samochod = this;
            samochodAktywacjaZmiany.Data = DateTime.Today;
            samochodAktywacjaZmiany.Operacja = "Deaktywacja";
            samochodAktywacjaZmiany.Save();
        }
    }
}