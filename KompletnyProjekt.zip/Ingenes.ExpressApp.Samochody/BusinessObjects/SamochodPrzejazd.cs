﻿using System;
using System.Linq;
using System.Text;
using DevExpress.Xpo;
using DevExpress.ExpressApp;
using System.ComponentModel;
using DevExpress.ExpressApp.DC;
using DevExpress.Data.Filtering;
using DevExpress.Persistent.Base;
using System.Collections.Generic;
using DevExpress.ExpressApp.Model;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace Ingenes.ExpressApp.Samochody.BusinessObjects
{
    [DefaultClassOptions]
    [NavigationItem("Ewidencja Samochodow")]

    //[ImageName("BO_Contact")]
    //[DefaultProperty("DisplayMemberNameForLookupEditorsOfThisType")]
    //[DefaultListViewOptions(MasterDetailMode.ListViewOnly, false, NewItemRowPosition.None)]
    //[Persistent("DatabaseTableName")]
    [Persistent("Przebieg")]
    [RuleCriteria("", DefaultContexts.Save, "StanLicznikaPrzed >= Samochod.OstatniPrzebieg", "StanLicznikaPrzed nie moze byc mniejszy od Ostatniego Przebiegu", SkipNullOrEmptyValues = false)]
    // Specify more UI options using a declarative approach (https://documentation.devexpress.com/#eXpressAppFramework/CustomDocument112701).
    public class SamochodPrzejazd : BaseObject
    { // Inherit from a different class to provide a custom primary key, concurrency and deletion behavior, etc. (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument113146.aspx).
        public SamochodPrzejazd(Session session)
            : base(session)
        {
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place your initialization code here (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112834.aspx).
        }

        protected override void OnSaving()
        {
            base.OnSaving();
            Samochod.OstatniPrzebieg = StanLicznikaPo;
        }

        private string _Pracownik;
        [RuleRequiredField(DefaultContexts.Save)]
        public string Pracownik
        {
            get { return _Pracownik; }
            set { SetPropertyValue("Pracownik", ref _Pracownik, value); }
        }

        private samochod _Samochod;
        [Association("samochod-przejazdy")]
        public samochod Samochod
        {
            get { return _Samochod; }
            set { SetPropertyValue("Samochod", ref _Samochod, value); }
        }

        private DateTime _DataWyjazdu;
        public DateTime DataWyjazdu
        {
            get { return _DataWyjazdu; }
            set { SetPropertyValue("DataWyjazdu", ref _DataWyjazdu, value); }
        }

        private string _CelWyjazdu;
        public string CelWyjazdu
        {
            get { return _CelWyjazdu; }
            set { SetPropertyValue("CelWyjazdu", ref _CelWyjazdu, value); }
        }

        private int _StanLicznikaPrzed;
        public int StanLicznikaPrzed
        {
            get { return _StanLicznikaPrzed; }
            set { SetPropertyValue("StanLicznikaPrzed", ref _StanLicznikaPrzed, value); }
            
        }
        

        private int _StanLicznikaPo;
        public int StanLicznikaPo
        {
            get { return _StanLicznikaPo; }
            set { SetPropertyValue("StanLicznikaPo", ref _StanLicznikaPo, value); }
        }

        public int Przebieg
        {
            get { return StanLicznikaPo - StanLicznikaPrzed; }
        }




        //[Action(Caption = "My UI Action", ConfirmationMessage = "Are you sure?", ImageName = "Attention", AutoCommit = true)]
        //public void ActionMethod() {
        //    // Trigger a custom business logic for the current record in the UI (https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112619.aspx).
        //    this.PersistentProperty = "Paid";
        //}
    }
}