﻿Folder Description

The "BusinessObjects" project folder is intended for storing the business objects 
code. In XAF, a business object can be implemented as a base persistent class 
descendant and as Domain Component interfaces.


Relevant Documentation

Business Model Design
https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112600.aspx

Domain Components
https://documentation.devexpress.com/eXpressAppFramework/CustomDocument113261.aspx
