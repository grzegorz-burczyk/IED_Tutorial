﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ingenes.ExpressApp.Modules.CoreModule;
using Ingenes.PluginsEngine;
using Ingenes.ExpressApp.Modules.CoreModule.Plugins;
namespace Ingenes.ExpressApp.Samochody
{

    [DodatekAttribiute(TypDodatku.Modul)]
    [DodatekOpis(Guid = "100C4FE2-B2B5-48A1-AA03-E04A34082700",
      Nazwa = "Przykładowy moduł Ewidencja samochodów",
      Autor = "INGENES - Bartosz Flis",
      Wersja = "1.0.0", Opis = "Ewidencja samochodów")]

    public class GetModule : IDodatekInterface
    {
        public IDodatekKonfiguracja KonfiguracjaDodatku
        {
            get
            {
                return null;
            }
        }
        public object Execute(object context)
        {
            return new Ingenes.ExpressApp.Samochody.SamochodyModule();
        }
    }
}
