﻿Folder Description

The "Images" project folder is intended for storing custom image files.


Relevant Documentation

Add and Override Images
https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112792.aspx

Assign a Custom Image
https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112744.aspx
